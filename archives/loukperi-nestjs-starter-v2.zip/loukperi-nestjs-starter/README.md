# LoukPeri Core — NestJS Starter Skeleton

Αυτό το πακέτο είναι ένα **starter skeleton** για το backend του LoukPeri Core.

## Τι περιέχει
- NestJS app bootstrap
- AppModule
- Config setup
- Database module με PrismaService
- Auth / Workspaces / Users / Roles / Records / Tasks modules
- DTO stubs με validation rules
- JWT strategy
- Prisma schema (minimal starter)
- Swagger setup

## Τι ΔΕΝ είναι ακόμα
- πλήρης business logic
- πλήρες RBAC implementation
- πλήρες Prisma schema από όλο το domain
- repository layer / mappers για όλα τα modules
- πραγματικά database queries

## Install
```bash
npm install
cp .env.example .env
npm run prisma:generate
npm run start:dev
```

## Docs
- Swagger: `/docs`
- API prefix: `/api/v1`

## Προτεινόμενο επόμενο βήμα
1. Σύνδεσε το starter με τα migration files που ήδη έχουμε.
2. Επέκτεινε το `schema.prisma` με όλο το domain.
3. Βάλε repository layer και activity logging.
4. Κούμπωσε guards για workspace + permissions.
