import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { LoginDto } from './dto/login.dto';
import { RefreshTokenDto } from './dto/refresh-token.dto';
import { LogoutDto } from './dto/logout.dto';

@Injectable()
export class AuthService {
  constructor(private readonly jwtService: JwtService) {}

  async login(dto: LoginDto) {
    const fakeUser = {
      sub: '00000000-0000-0000-0000-000000000001',
      email: dto.email,
      permissions: ['workspace.read', 'records.read'],
      workspaceIds: ['00000000-0000-0000-0000-000000000010'],
    };

    return {
      access_token: await this.jwtService.signAsync(fakeUser),
      refresh_token: 'refresh-token-placeholder',
      user: {
        id: fakeUser.sub,
        email: fakeUser.email,
      },
      workspaces: [
        {
          id: fakeUser.workspaceIds[0],
          name: 'Demo Client',
          slug: 'demo-client',
        },
      ],
    };
  }

  async refresh(dto: RefreshTokenDto) {
    if (!dto.refresh_token) {
      throw new UnauthorizedException('Missing refresh token');
    }

    return {
      access_token: await this.jwtService.signAsync({
        sub: '00000000-0000-0000-0000-000000000001',
        email: 'admin@client.com',
        permissions: ['workspace.read', 'records.read'],
      }),
      refresh_token: dto.refresh_token,
    };
  }

  async logout(_dto: LogoutDto) {
    return { success: true };
  }

  async me(user: unknown) {
    return user;
  }
}
