import { Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { ListUsersQueryDto } from './dto/list-users.query.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Injectable()
export class UsersService {
  async list(query: ListUsersQueryDto) {
    return {
      items: [],
      pagination: {
        page: query.page,
        page_size: query.page_size,
        total: 0,
        total_pages: 0,
      },
    };
  }

  async create(dto: CreateUserDto) {
    return {
      id: '00000000-0000-0000-0000-000000000100',
      ...dto,
    };
  }

  async getOne(userId: string) {
    return {
      id: userId,
      email: 'user@example.com',
      first_name: 'Demo',
      last_name: 'User',
    };
  }

  async update(userId: string, dto: UpdateUserDto) {
    return {
      id: userId,
      ...dto,
    };
  }
}
