import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards, UseInterceptors } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Permissions } from 'src/common/decorators/permissions.decorator';
import { JwtAuthGuard } from 'src/common/guards/jwt-auth.guard';
import { PermissionsGuard } from 'src/common/guards/permissions.guard';
import { ResponseEnvelopeInterceptor } from 'src/common/interceptors/response-envelope.interceptor';
import { CompleteTaskDto } from './dto/complete-task.dto';
import { CreateTaskDto } from './dto/create-task.dto';
import { ListTasksQueryDto } from './dto/list-tasks.query.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { TasksService } from './tasks.service';

@ApiTags('Tasks')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, PermissionsGuard)
@UseInterceptors(ResponseEnvelopeInterceptor)
@Controller('tasks')
export class TasksController {
  constructor(private readonly tasksService: TasksService) {}

  @Get()
  @Permissions('tasks.read')
  list(@Query() query: ListTasksQueryDto) {
    return this.tasksService.list(query);
  }

  @Post()
  @Permissions('tasks.create')
  create(@Body() dto: CreateTaskDto) {
    return this.tasksService.create(dto);
  }

  @Get(':taskId')
  @Permissions('tasks.read')
  getOne(@Param('taskId') taskId: string) {
    return this.tasksService.getOne(taskId);
  }

  @Patch(':taskId')
  @Permissions('tasks.update')
  update(@Param('taskId') taskId: string, @Body() dto: UpdateTaskDto) {
    return this.tasksService.update(taskId, dto);
  }

  @Post(':taskId/complete')
  @Permissions('tasks.complete')
  complete(@Param('taskId') taskId: string, @Body() dto: CompleteTaskDto) {
    return this.tasksService.complete(taskId, dto);
  }

  @Post(':taskId/reopen')
  @Permissions('tasks.update')
  reopen(@Param('taskId') taskId: string) {
    return this.tasksService.reopen(taskId);
  }
}
