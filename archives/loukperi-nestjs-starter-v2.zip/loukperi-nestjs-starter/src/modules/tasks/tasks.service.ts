import { Injectable } from '@nestjs/common';
import { CompleteTaskDto } from './dto/complete-task.dto';
import { CreateTaskDto } from './dto/create-task.dto';
import { ListTasksQueryDto } from './dto/list-tasks.query.dto';
import { UpdateTaskDto } from './dto/update-task.dto';

@Injectable()
export class TasksService {
  async list(query: ListTasksQueryDto) {
    return {
      items: [],
      pagination: {
        page: query.page,
        page_size: query.page_size,
        total: 0,
        total_pages: 0,
      },
    };
  }

  async create(dto: CreateTaskDto) {
    return { id: '00000000-0000-0000-0000-000000000400', ...dto };
  }

  async getOne(taskId: string) {
    return { id: taskId, title: 'Demo Task', status: 'open' };
  }

  async update(taskId: string, dto: UpdateTaskDto) {
    return { id: taskId, ...dto };
  }

  async complete(taskId: string, dto: CompleteTaskDto) {
    return { id: taskId, status: 'completed', note: dto.note };
  }

  async reopen(taskId: string) {
    return { id: taskId, status: 'open' };
  }
}
