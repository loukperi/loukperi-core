import { Injectable } from '@nestjs/common';
import { UpdateWorkspaceDto } from './dto/update-workspace.dto';
import { UpdateWorkspaceSettingsDto } from './dto/update-workspace-settings.dto';

@Injectable()
export class WorkspacesService {
  async getCurrent(workspaceId?: string) {
    return {
      id: workspaceId ?? '00000000-0000-0000-0000-000000000010',
      name: 'Demo Client',
      slug: 'demo-client',
      timezone: 'Europe/Athens',
      locale: 'el-GR',
      is_active: true,
    };
  }

  async updateCurrent(workspaceId: string | undefined, dto: UpdateWorkspaceDto) {
    return {
      id: workspaceId ?? '00000000-0000-0000-0000-000000000010',
      ...dto,
    };
  }

  async getSettings(workspaceId?: string) {
    return {
      workspace_id: workspaceId ?? '00000000-0000-0000-0000-000000000010',
      default_record_label_singular: 'Record',
      default_record_label_plural: 'Records',
      date_format: 'DD/MM/YYYY',
      currency_code: 'EUR',
      number_format: 'el-GR',
      features_jsonb: {},
    };
  }

  async updateSettings(
    workspaceId: string | undefined,
    dto: UpdateWorkspaceSettingsDto,
  ) {
    return {
      workspace_id: workspaceId ?? '00000000-0000-0000-0000-000000000010',
      ...dto,
    };
  }
}
