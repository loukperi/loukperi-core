import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UseInterceptors } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Permissions } from 'src/common/decorators/permissions.decorator';
import { JwtAuthGuard } from 'src/common/guards/jwt-auth.guard';
import { PermissionsGuard } from 'src/common/guards/permissions.guard';
import { ResponseEnvelopeInterceptor } from 'src/common/interceptors/response-envelope.interceptor';
import { AssignRecordDto } from './dto/assign-record.dto';
import { AssignTagDto } from './dto/assign-tag.dto';
import { ChangeRecordStatusDto } from './dto/change-record-status.dto';
import { CreateRecordDto } from './dto/create-record.dto';
import { ListRecordsQueryDto } from './dto/list-records.query.dto';
import { UpdateRecordDto } from './dto/update-record.dto';
import { RecordsService } from './records.service';

@ApiTags('Records')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, PermissionsGuard)
@UseInterceptors(ResponseEnvelopeInterceptor)
@Controller('records')
export class RecordsController {
  constructor(private readonly recordsService: RecordsService) {}

  @Get()
  @Permissions('records.read')
  list(@Query() query: ListRecordsQueryDto) {
    return this.recordsService.list(query);
  }

  @Post()
  @Permissions('records.create')
  create(@Body() dto: CreateRecordDto) {
    return this.recordsService.create(dto);
  }

  @Get(':recordId')
  @Permissions('records.read')
  getOne(@Param('recordId') recordId: string) {
    return this.recordsService.getOne(recordId);
  }

  @Patch(':recordId')
  @Permissions('records.update')
  update(@Param('recordId') recordId: string, @Body() dto: UpdateRecordDto) {
    return this.recordsService.update(recordId, dto);
  }

  @Post(':recordId/status')
  @Permissions('records.change_status')
  changeStatus(
    @Param('recordId') recordId: string,
    @Body() dto: ChangeRecordStatusDto,
  ) {
    return this.recordsService.changeStatus(recordId, dto);
  }

  @Post(':recordId/assign')
  @Permissions('records.assign')
  assign(@Param('recordId') recordId: string, @Body() dto: AssignRecordDto) {
    return this.recordsService.assign(recordId, dto);
  }

  @Post(':recordId/tags')
  @Permissions('records.update')
  assignTag(@Param('recordId') recordId: string, @Body() dto: AssignTagDto) {
    return this.recordsService.assignTag(recordId, dto);
  }

  @Delete(':recordId/tags/:tagId')
  @Permissions('records.update')
  removeTag(@Param('recordId') recordId: string, @Param('tagId') tagId: string) {
    return this.recordsService.removeTag(recordId, tagId);
  }
}
