import { Injectable } from '@nestjs/common';
import { AssignRecordDto } from './dto/assign-record.dto';
import { AssignTagDto } from './dto/assign-tag.dto';
import { ChangeRecordStatusDto } from './dto/change-record-status.dto';
import { CreateRecordDto } from './dto/create-record.dto';
import { ListRecordsQueryDto } from './dto/list-records.query.dto';
import { UpdateRecordDto } from './dto/update-record.dto';

@Injectable()
export class RecordsService {
  async list(query: ListRecordsQueryDto) {
    return {
      items: [],
      pagination: {
        page: query.page,
        page_size: query.page_size,
        total: 0,
        total_pages: 0,
      },
    };
  }

  async create(dto: CreateRecordDto) {
    return { id: '00000000-0000-0000-0000-000000000300', ...dto };
  }

  async getOne(recordId: string) {
    return { id: recordId, title: 'Demo Record', priority: 'medium' };
  }

  async update(recordId: string, dto: UpdateRecordDto) {
    return { id: recordId, ...dto };
  }

  async changeStatus(recordId: string, dto: ChangeRecordStatusDto) {
    return { id: recordId, status_id: dto.status_id, note: dto.note };
  }

  async assign(recordId: string, dto: AssignRecordDto) {
    return { id: recordId, assignee_user_id: dto.assignee_user_id };
  }

  async assignTag(recordId: string, dto: AssignTagDto) {
    return { id: recordId, tag_id: dto.tag_id };
  }

  async removeTag(recordId: string, tagId: string) {
    return { id: recordId, removed_tag_id: tagId };
  }
}
