import { PrismaClient } from '@prisma/client';
import * as argon2 from 'argon2';

const prisma = new PrismaClient();

async function main(): Promise<void> {
  const workspace = await prisma.workspace.upsert({
    where: { slug: 'demo-client' },
    update: {
      name: 'Demo Client',
      isActive: true,
    },
    create: {
      name: 'Demo Client',
      slug: 'demo-client',
      companyName: 'Demo Client SA',
      timezone: 'Europe/Athens',
      locale: 'el-GR',
      isActive: true,
    },
  });

  await prisma.workspaceSettings.upsert({
    where: { workspaceId: workspace.id },
    update: {},
    create: {
      workspaceId: workspace.id,
      defaultRecordLabelSingular: 'Order',
      defaultRecordLabelPlural: 'Orders',
      featuresJson: {},
    },
  });

  const admin = await prisma.user.upsert({
    where: { email: 'admin@client.com' },
    update: {},
    create: {
      email: 'admin@client.com',
      passwordHash: await argon2.hash('ChangeMe123!'),
      firstName: 'Demo',
      lastName: 'Admin',
      isActive: true,
    },
  });

  const workspaceUser = await prisma.workspaceUser.upsert({
    where: {
      workspaceId_userId: {
        workspaceId: workspace.id,
        userId: admin.id,
      },
    },
    update: {
      status: 'active',
      isOwner: true,
    },
    create: {
      workspaceId: workspace.id,
      userId: admin.id,
      status: 'active',
      isOwner: true,
      jobTitle: 'Client Admin',
    },
  });

  const roleCodes = [
    { code: 'client_admin', name: 'Client Admin' },
    { code: 'manager', name: 'Manager' },
    { code: 'operator', name: 'Operator' },
    { code: 'viewer', name: 'Viewer' },
  ];

  const roles = [] as Array<{ id: string; code: string }>;
  for (const roleData of roleCodes) {
    const role = await prisma.role.upsert({
      where: {
        workspaceId_code: {
          workspaceId: workspace.id,
          code: roleData.code,
        },
      },
      update: {
        name: roleData.name,
      },
      create: {
        workspaceId: workspace.id,
        code: roleData.code,
        name: roleData.name,
        isSystemRole: true,
      },
    });
    roles.push({ id: role.id, code: role.code });
  }

  const clientAdminRole = roles.find((role) => role.code === 'client_admin');
  if (clientAdminRole) {
    await prisma.workspaceUserRole.upsert({
      where: {
        workspaceId_workspaceUserId_roleId: {
          workspaceId: workspace.id,
          workspaceUserId: workspaceUser.id,
          roleId: clientAdminRole.id,
        },
      },
      update: {},
      create: {
        workspaceId: workspace.id,
        workspaceUserId: workspaceUser.id,
        roleId: clientAdminRole.id,
      },
    });
  }

  const recordType = await prisma.recordType.upsert({
    where: {
      workspaceId_key: {
        workspaceId: workspace.id,
        key: 'order',
      },
    },
    update: {},
    create: {
      workspaceId: workspace.id,
      key: 'order',
      singularLabel: 'Order',
      pluralLabel: 'Orders',
      isActive: true,
    },
  });

  const statuses = [
    { key: 'new', label: 'New', sortOrder: 1, isDefault: true, isTerminal: false },
    { key: 'in_progress', label: 'In Progress', sortOrder: 2, isDefault: false, isTerminal: false },
    { key: 'completed', label: 'Completed', sortOrder: 3, isDefault: false, isTerminal: true },
  ];

  for (const status of statuses) {
    await prisma.statusDefinition.upsert({
      where: {
        workspaceId_entityType_recordTypeId_key: {
          workspaceId: workspace.id,
          entityType: 'record',
          recordTypeId: recordType.id,
          key: status.key,
        },
      },
      update: {
        label: status.label,
        sortOrder: status.sortOrder,
        isDefault: status.isDefault,
        isTerminal: status.isTerminal,
      },
      create: {
        workspaceId: workspace.id,
        entityType: 'record',
        recordTypeId: recordType.id,
        key: status.key,
        label: status.label,
        sortOrder: status.sortOrder,
        isDefault: status.isDefault,
        isTerminal: status.isTerminal,
      },
    });
  }

  const defaultStatus = await prisma.statusDefinition.findFirstOrThrow({
    where: {
      workspaceId: workspace.id,
      entityType: 'record',
      recordTypeId: recordType.id,
      isDefault: true,
    },
  });

  await prisma.record.create({
    data: {
      workspaceId: workspace.id,
      recordTypeId: recordType.id,
      title: 'ORD-1001',
      code: 'ORD-1001',
      description: 'Demo seeded order',
      statusId: defaultStatus.id,
      priority: 'medium',
      ownerUserId: admin.id,
      assigneeUserId: admin.id,
      dataJson: {},
      customFieldsJson: {},
    },
  }).catch(() => undefined);

  await prisma.task.create({
    data: {
      workspaceId: workspace.id,
      title: 'Call customer',
      description: 'Follow up on seeded order',
      status: 'open',
      priority: 'medium',
      assigneeUserId: admin.id,
      createdByUserId: admin.id,
    },
  }).catch(() => undefined);

  console.log('Seed completed');
}

main()
  .catch(async (error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
