import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { AuthRepository } from './repositories/auth.repository';
import { WorkspaceRepository } from './repositories/workspace.repository';
import { UserRepository } from './repositories/user.repository';
import { RecordRepository } from './repositories/record.repository';
import { TaskRepository } from './repositories/task.repository';

@Global()
@Module({
  providers: [
    PrismaService,
    AuthRepository,
    WorkspaceRepository,
    UserRepository,
    RecordRepository,
    TaskRepository,
  ],
  exports: [
    PrismaService,
    AuthRepository,
    WorkspaceRepository,
    UserRepository,
    RecordRepository,
    TaskRepository,
  ],
})
export class DatabaseModule {}
