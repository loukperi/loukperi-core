import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CurrentUserPayload } from 'src/common/decorators/current-user.decorator';
import { RecordRepository } from 'src/database/repositories/record.repository';
import { AssignRecordDto } from './dto/assign-record.dto';
import { AssignTagDto } from './dto/assign-tag.dto';
import { ChangeRecordStatusDto } from './dto/change-record-status.dto';
import { CreateRecordDto } from './dto/create-record.dto';
import { ListRecordsQueryDto } from './dto/list-records.query.dto';
import { UpdateRecordDto } from './dto/update-record.dto';

@Injectable()
export class RecordsService {
  constructor(private readonly recordRepository: RecordRepository) {}

  async list(
    workspaceId: string | undefined,
    currentUser: CurrentUserPayload | undefined,
    query: ListRecordsQueryDto,
  ) {
    const resolvedWorkspaceId = this.resolveWorkspaceId(workspaceId, currentUser);
    this.validateDateRange(query.due_after, query.due_before);

    const result = await this.recordRepository.listByWorkspace(resolvedWorkspaceId, query);

    return {
      items: result.items.map((item) => this.toRecordResponse(item)),
      pagination: {
        page: query.page,
        page_size: query.page_size,
        total: result.total,
        total_pages: Math.ceil(result.total / query.page_size),
      },
    };
  }

  async create(
    workspaceId: string | undefined,
    currentUser: CurrentUserPayload | undefined,
    dto: CreateRecordDto,
  ) {
    const resolvedWorkspaceId = this.resolveWorkspaceId(workspaceId, currentUser);
    this.validateDates(dto.opened_at, dto.due_at);

    const created = await this.recordRepository.create({
      workspaceId: resolvedWorkspaceId,
      recordTypeId: dto.record_type_id,
      accountId: dto.account_id,
      contactId: dto.contact_id,
      title: dto.title,
      code: dto.code,
      description: dto.description,
      statusId: dto.status_id,
      priority: dto.priority,
      ownerUserId: dto.owner_user_id,
      assigneeUserId: dto.assignee_user_id,
      openedAt: dto.opened_at ? new Date(dto.opened_at) : undefined,
      dueAt: dto.due_at ? new Date(dto.due_at) : undefined,
      sourceSystem: dto.source_system,
      sourceExternalId: dto.source_external_id,
      sourceUrl: dto.source_url,
      dataJson: dto.data_jsonb ?? {},
      customFieldsJson: dto.custom_fields ?? {},
    });

    return this.toRecordResponse(created);
  }

  async getOne(
    workspaceId: string | undefined,
    currentUser: CurrentUserPayload | undefined,
    recordId: string,
  ) {
    const resolvedWorkspaceId = this.resolveWorkspaceId(workspaceId, currentUser);
    const record = await this.recordRepository.findOne(resolvedWorkspaceId, recordId);

    if (!record) {
      throw new NotFoundException('Record not found');
    }

    return this.toRecordResponse(record);
  }

  async update(
    workspaceId: string | undefined,
    currentUser: CurrentUserPayload | undefined,
    recordId: string,
    dto: UpdateRecordDto,
  ) {
    const resolvedWorkspaceId = this.resolveWorkspaceId(workspaceId, currentUser);
    this.validateDates(dto.opened_at, dto.due_at, dto.closed_at);

    const existing = await this.recordRepository.findOne(resolvedWorkspaceId, recordId);
    if (!existing) {
      throw new NotFoundException('Record not found');
    }

    const updated = await this.recordRepository.update(recordId, {
      recordTypeId: dto.record_type_id,
      accountId: dto.account_id,
      contactId: dto.contact_id,
      title: dto.title,
      code: dto.code,
      description: dto.description,
      statusId: dto.status_id,
      priority: dto.priority,
      ownerUserId: dto.owner_user_id,
      assigneeUserId: dto.assignee_user_id,
      openedAt: dto.opened_at ? new Date(dto.opened_at) : undefined,
      dueAt: dto.due_at ? new Date(dto.due_at) : undefined,
      closedAt: dto.closed_at ? new Date(dto.closed_at) : undefined,
      sourceSystem: dto.source_system,
      sourceExternalId: dto.source_external_id,
      sourceUrl: dto.source_url,
      dataJson: dto.data_jsonb,
      customFieldsJson: dto.custom_fields,
    });

    return this.toRecordResponse(updated);
  }

  async changeStatus(
    workspaceId: string | undefined,
    currentUser: CurrentUserPayload | undefined,
    recordId: string,
    dto: ChangeRecordStatusDto,
  ) {
    const resolvedWorkspaceId = this.resolveWorkspaceId(workspaceId, currentUser);
    const existing = await this.recordRepository.findOne(resolvedWorkspaceId, recordId);
    if (!existing) {
      throw new NotFoundException('Record not found');
    }

    const updated = await this.recordRepository.update(recordId, {
      statusId: dto.status_id,
    });

    return {
      ...this.toRecordResponse(updated),
      status_note: dto.note ?? null,
    };
  }

  async assign(
    workspaceId: string | undefined,
    currentUser: CurrentUserPayload | undefined,
    recordId: string,
    dto: AssignRecordDto,
  ) {
    const resolvedWorkspaceId = this.resolveWorkspaceId(workspaceId, currentUser);
    const existing = await this.recordRepository.findOne(resolvedWorkspaceId, recordId);
    if (!existing) {
      throw new NotFoundException('Record not found');
    }

    const updated = await this.recordRepository.update(recordId, {
      assigneeUserId: dto.assignee_user_id,
    });

    return this.toRecordResponse(updated);
  }

  async assignTag(
    workspaceId: string | undefined,
    currentUser: CurrentUserPayload | undefined,
    recordId: string,
    dto: AssignTagDto,
  ) {
    await this.getOne(workspaceId, currentUser, recordId);
    return {
      id: recordId,
      assigned_tag_id: dto.tag_id,
    };
  }

  async removeTag(
    workspaceId: string | undefined,
    currentUser: CurrentUserPayload | undefined,
    recordId: string,
    tagId: string,
  ) {
    await this.getOne(workspaceId, currentUser, recordId);
    return {
      id: recordId,
      removed_tag_id: tagId,
    };
  }

  private resolveWorkspaceId(
    workspaceId: string | undefined,
    currentUser: CurrentUserPayload | undefined,
  ) {
    const resolvedWorkspaceId = workspaceId ?? currentUser?.defaultWorkspaceId;
    if (!resolvedWorkspaceId) {
      throw new ForbiddenException('Workspace context is required');
    }

    if (!currentUser || !currentUser.workspaceIds.includes(resolvedWorkspaceId)) {
      throw new ForbiddenException('No access to workspace');
    }

    return resolvedWorkspaceId;
  }

  private validateDateRange(dueAfter?: string, dueBefore?: string) {
    if (dueAfter && dueBefore && new Date(dueAfter) > new Date(dueBefore)) {
      throw new BadRequestException('due_after cannot be greater than due_before');
    }
  }

  private validateDates(openedAt?: string, dueAt?: string, closedAt?: string) {
    if (openedAt && dueAt && new Date(openedAt) > new Date(dueAt)) {
      throw new BadRequestException('opened_at cannot be greater than due_at');
    }

    if (dueAt && closedAt && new Date(dueAt) > new Date(closedAt)) {
      throw new BadRequestException('due_at cannot be greater than closed_at');
    }
  }

  private toRecordResponse(record: {
    id: string;
    recordTypeId: string;
    title: string;
    code: string | null;
    description: string | null;
    statusId: string | null;
    priority: string;
    ownerUserId: string | null;
    assigneeUserId: string | null;
    accountId: string | null;
    contactId: string | null;
    openedAt: Date | null;
    dueAt: Date | null;
    closedAt: Date | null;
    sourceSystem: string | null;
    sourceExternalId: string | null;
    sourceUrl: string | null;
    dataJson: unknown;
    customFieldsJson: unknown;
    createdAt: Date;
    updatedAt: Date;
    recordType?: {
      id: string;
      key: string;
      singularLabel: string;
      pluralLabel: string;
    };
  }) {
    return {
      id: record.id,
      record_type_id: record.recordTypeId,
      record_type: record.recordType
        ? {
            id: record.recordType.id,
            key: record.recordType.key,
            singular_label: record.recordType.singularLabel,
            plural_label: record.recordType.pluralLabel,
          }
        : null,
      title: record.title,
      code: record.code,
      description: record.description,
      status_id: record.statusId,
      priority: record.priority,
      owner_user_id: record.ownerUserId,
      assignee_user_id: record.assigneeUserId,
      account_id: record.accountId,
      contact_id: record.contactId,
      opened_at: record.openedAt,
      due_at: record.dueAt,
      closed_at: record.closedAt,
      source_system: record.sourceSystem,
      source_external_id: record.sourceExternalId,
      source_url: record.sourceUrl,
      data_jsonb: record.dataJson ?? {},
      custom_fields: record.customFieldsJson ?? {},
      created_at: record.createdAt,
      updated_at: record.updatedAt,
    };
  }
}
