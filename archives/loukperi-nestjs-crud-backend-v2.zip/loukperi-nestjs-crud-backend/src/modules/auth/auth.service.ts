import {
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import * as argon2 from 'argon2';
import { CurrentUserPayload } from 'src/common/decorators/current-user.decorator';
import { resolvePermissionsFromRoleCodes } from 'src/common/constants/role-permissions-map';
import { AuthRepository } from 'src/database/repositories/auth.repository';
import { LoginDto } from './dto/login.dto';
import { LogoutDto } from './dto/logout.dto';
import { RefreshTokenDto } from './dto/refresh-token.dto';

@Injectable()
export class AuthService {
  constructor(
    private readonly authRepository: AuthRepository,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  async login(dto: LoginDto) {
    const user = await this.authRepository.findUserByEmail(dto.email);

    if (!user || !user.isActive) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const passwordMatches = await this.verifyPassword(dto.password, user.passwordHash);
    if (!passwordMatches) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const authPayload = this.buildAuthPayload(user);
    await this.authRepository.markLastLogin(user.id);

    return {
      access_token: await this.jwtService.signAsync(authPayload),
      refresh_token: await this.jwtService.signAsync(
        {
          sub: user.id,
          email: user.email,
          type: 'refresh',
        },
        {
          secret:
            this.configService.get<string>('auth.refreshSecret') ?? 'change-me-refresh',
          expiresIn:
            this.configService.get<string>('auth.refreshTtl') ?? '30d',
        },
      ),
      user: {
        id: user.id,
        email: user.email,
        first_name: user.firstName,
        last_name: user.lastName,
      },
      workspaces: authPayload.workspaceIds.map((workspaceId) => {
        const membership = user.memberships.find((item) => item.workspaceId === workspaceId);
        return {
          id: membership?.workspace.id ?? workspaceId,
          name: membership?.workspace.name ?? 'Workspace',
          slug: membership?.workspace.slug ?? 'workspace',
        };
      }),
    };
  }

  async refresh(dto: RefreshTokenDto) {
    try {
      const decoded = await this.jwtService.verifyAsync<{ sub: string; type?: string }>(
        dto.refresh_token,
        {
          secret:
            this.configService.get<string>('auth.refreshSecret') ?? 'change-me-refresh',
        },
      );

      if (decoded.type !== 'refresh') {
        throw new UnauthorizedException('Invalid refresh token');
      }

      const user = await this.authRepository.findUserById(decoded.sub);
      if (!user || !user.isActive) {
        throw new UnauthorizedException('Invalid refresh token');
      }

      const authPayload = this.buildAuthPayload(user);

      return {
        access_token: await this.jwtService.signAsync(authPayload),
        refresh_token: await this.jwtService.signAsync(
          {
            sub: user.id,
            email: user.email,
            type: 'refresh',
          },
          {
            secret:
              this.configService.get<string>('auth.refreshSecret') ?? 'change-me-refresh',
            expiresIn:
              this.configService.get<string>('auth.refreshTtl') ?? '30d',
          },
        ),
      };
    } catch {
      throw new UnauthorizedException('Invalid refresh token');
    }
  }

  async logout(_dto: LogoutDto) {
    return { success: true };
  }

  async me(user: CurrentUserPayload | undefined) {
    if (!user) {
      throw new UnauthorizedException('Unauthorized');
    }

    const currentUser = await this.authRepository.findUserById(user.sub);
    if (!currentUser) {
      throw new UnauthorizedException('Unauthorized');
    }

    const authPayload = this.buildAuthPayload(currentUser);

    return {
      user: {
        id: currentUser.id,
        email: currentUser.email,
        first_name: currentUser.firstName,
        last_name: currentUser.lastName,
        is_active: currentUser.isActive,
      },
      memberships: currentUser.memberships.map((membership) => ({
        id: membership.id,
        workspace_id: membership.workspaceId,
        workspace_name: membership.workspace.name,
        workspace_slug: membership.workspace.slug,
        status: membership.status,
        is_owner: membership.isOwner,
        roles: membership.roles.map((item) => ({
          id: item.role.id,
          code: item.role.code,
          name: item.role.name,
        })),
      })),
      effective_permissions: authPayload.permissions,
      default_workspace_id: authPayload.defaultWorkspaceId,
    };
  }

  private buildAuthPayload(user: Awaited<ReturnType<AuthRepository['findUserById']>>) {
    if (!user) {
      throw new UnauthorizedException('Unauthorized');
    }

    const activeMemberships = user.memberships.filter(
      (membership) => membership.status === 'active' && membership.workspace.isActive,
    );

    const workspaceIds = activeMemberships.map((membership) => membership.workspaceId);
    const roleCodes = activeMemberships.flatMap((membership) =>
      membership.roles.map((item) => item.role.code),
    );
    const permissions = resolvePermissionsFromRoleCodes(roleCodes);

    return {
      sub: user.id,
      email: user.email,
      workspaceIds,
      defaultWorkspaceId: workspaceIds[0],
      permissions,
    };
  }

  private async verifyPassword(plainTextPassword: string, passwordHash: string) {
    if (passwordHash.startsWith('$argon2')) {
      return argon2.verify(passwordHash, plainTextPassword);
    }

    if (passwordHash.startsWith('plain:')) {
      return passwordHash === `plain:${plainTextPassword}`;
    }

    return false;
  }
}
